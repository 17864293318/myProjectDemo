/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : school

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2019-03-18 10:23:53
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(255) DEFAULT NULL,
  `teacher_id` int(11) NOT NULL,
  PRIMARY KEY (`course_id`),
  KEY `sou_tea_f` (`teacher_id`),
  CONSTRAINT `sou_tea_f` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`teacher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES ('1', '语文', '1');
INSERT INTO `course` VALUES ('2', '数学', '2');
INSERT INTO `course` VALUES ('3', '英语', '3');
INSERT INTO `course` VALUES ('4', '物理', '3');

-- ----------------------------
-- Table structure for score
-- ----------------------------
DROP TABLE IF EXISTS `score`;
CREATE TABLE `score` (
  `score_id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `score_cont` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`score_id`),
  KEY `stu_f` (`stu_id`),
  KEY `cou_f` (`course_id`),
  CONSTRAINT `cou_f` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`),
  CONSTRAINT `stu_f` FOREIGN KEY (`stu_id`) REFERENCES `student` (`stu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of score
-- ----------------------------
INSERT INTO `score` VALUES ('1', '1', '1', '50');
INSERT INTO `score` VALUES ('2', '1', '2', '80');
INSERT INTO `score` VALUES ('3', '1', '3', '20');
INSERT INTO `score` VALUES ('4', '2', '1', '10');
INSERT INTO `score` VALUES ('5', '2', '2', '89');
INSERT INTO `score` VALUES ('6', '2', '3', '68');
INSERT INTO `score` VALUES ('7', '3', '1', '99');
INSERT INTO `score` VALUES ('8', '3', '2', '89');
INSERT INTO `score` VALUES ('9', '1', '4', '29');
INSERT INTO `score` VALUES ('10', '2', '4', '94');
INSERT INTO `score` VALUES ('11', '3', '3', '55');
INSERT INTO `score` VALUES ('12', '4', '1', '11');
INSERT INTO `score` VALUES ('13', '4', '2', '33');
INSERT INTO `score` VALUES ('14', '4', '3', '22');

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `stu_id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_name` varchar(255) DEFAULT NULL,
  `stu_age` varchar(255) DEFAULT NULL,
  `stu_gender` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`stu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1', '张三', '12', 'm');
INSERT INTO `student` VALUES ('2', '李四', '23', 'm');
INSERT INTO `student` VALUES ('3', '王五', '22', 'w');
INSERT INTO `student` VALUES ('4', '赵六', '33', 'w');

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `teacher_id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`teacher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES ('1', '张龙');
INSERT INTO `teacher` VALUES ('2', '赵虎');
INSERT INTO `teacher` VALUES ('3', '王朝');
