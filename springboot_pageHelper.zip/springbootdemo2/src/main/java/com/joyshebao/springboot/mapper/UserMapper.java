package com.joyshebao.springboot.mapper;

import com.joyshebao.springboot.model.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserMapper {
    User findUserByName(@Param("name") String name);

    public List<User> ListUser();
}
