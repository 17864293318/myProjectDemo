package com.joyshebao.springboot.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.joyshebao.springboot.model.User;
import com.joyshebao.springboot.service.UserService;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping(value="/",method=RequestMethod.GET)
    public String showIndex(){
        return "index";
    }

    @RequestMapping("/userlist")
    @ResponseBody
    public String listUser(@RequestParam(value = "page",defaultValue = "2") Integer page, @RequestParam(value = "limit",defaultValue = "2") Integer limit){
        JSONObject map = new JSONObject();
        PageHelper.startPage(page-1,limit);
        List<User> userList =userService.userList(page,limit);
        //设置返回总记录数
        PageInfo<User> pageInfo = new PageInfo<>(userList);
        map.put("code",0);
        map.put("count",pageInfo.getTotal());
        map.put("data",userList);
        return map.toString();
    }

    @RequestMapping("/byname")
    @ResponseBody
    public User getUserByName(String name){
        return userService.findByName(name);
    }
}
