package com.joyshebao.springboot.controller;

import com.joyshebao.springboot.model.User;
import com.joyshebao.springboot.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping(value="/",method=RequestMethod.GET)
    public String showIndex(){
        return "index";
    }

    @RequestMapping("/userlist")
    @ResponseBody
    public List<User> ListUser(){
        return userService.userList();
    }

    @RequestMapping("/byname")
    @ResponseBody
    public List<User> getUserByName(String name){
        return userService.findByName(name);
    }
}
