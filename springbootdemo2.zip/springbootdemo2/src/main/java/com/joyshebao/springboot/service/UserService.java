package com.joyshebao.springboot.service;

import com.joyshebao.springboot.mapper.UserMapper;
import com.joyshebao.springboot.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    public UserMapper userMapper;
    public List<User> findByName(String name){
        return userMapper.findUserByName(name);
    }

    public  List<User> userList(){
        return userMapper.ListUser();
    }
}
