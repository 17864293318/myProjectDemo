package com.joyshebao.springboot.mapper;

import com.joyshebao.springboot.model.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UserMapper {
    List<User> findUserByName(String name);

    public List<User> ListUser();
}
