package com.joyshebao.springboot.service;

import com.github.pagehelper.PageHelper;
import com.joyshebao.springboot.mapper.UserMapper;
import com.joyshebao.springboot.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    public UserMapper userMapper;
    public User findByName(String name){
        return userMapper.findUserByName(name);
    }

    public List<User> userList(Integer page, Integer limit){
        PageHelper.startPage(page-1,limit);
        return userMapper.ListUser();
    }
}
